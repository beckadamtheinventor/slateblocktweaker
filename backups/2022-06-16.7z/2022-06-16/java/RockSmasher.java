package ${mod.package}.registry;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.Material;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.*;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.Objects;
import java.util.Random;

public class RockSmasher extends ToolItem {
    public RockSmasher(ToolItem.Settings settings) {
        super(ToolMaterials.STONE, settings);
    }

    private static void giveItem(ItemUsageContext context, Block block) {
		giveItem(context, new ItemStack(block.asItem()));
    }

	private static void giveItem(ItemUsageContext context, Item item) {
		giveItem(context, new ItemStack(item));
	}

	private static void giveItem(ItemUsageContext context, ItemStack item) {
        if (!context.getWorld().isClient) {
			BlockPos pos = context.getBlockPos();
			World world = context.getWorld();
			world.spawnEntity(new ItemEntity(world, pos.getX() + 0.5f, pos.getY() + 0.5f, pos.getZ() + 0.5f, item));
        }
    }

	private void damageItem(ItemUsageContext context) {
		context.getStack().damage(1, Objects.requireNonNull(context.getPlayer()), playerEntity -> playerEntity.getMainHandStack().setCount(0));
	}

	public static boolean smashBlock(ItemUsageContext context) {
		final World world = context.getWorld();
		final Random random = world.getRandom();
		final BlockPos pos = context.getBlockPos();
		final BlockState block = world.getBlockState(pos);
		if (block.getMaterial().equals(Material.LEAVES)) {
			world.breakBlock(pos, false);
			if (random.nextInt(20) == 0) {
				giveItem(context, ModItems.DAMP_MOSS);
			} else {
				giveItem(context, ModItems.ORGANIC_MASS);
			}
			if (random.nextInt(3) == 0) {
				giveItem(context, Items.STICK);
			}
			if (random.nextInt(10) == 0) {
				giveItem(context, Items.APPLE);
			}
			return true;
		} else if (block.equals(ModBlocks.GRAVELLY_SILT.getDefaultState())) {
			world.breakBlock(pos, false);
			giveItem(context, ModItems.FLINT_SHARD);
			if (random.nextInt(4) > 2) {
				giveItem(context, ModItems.FLINT_SHARD);
			}
			if (random.nextInt(64) == 0) {
				giveItem(context, Items.POINTED_DRIPSTONE);
			}
			return true;
		} else if (block.equals(Blocks.COBBLESTONE.getDefaultState())) {
			world.breakBlock(pos, false);
			if (random.nextInt(4) == 0) {
				giveItem(context, Blocks.COARSE_DIRT);
			} else {
				giveItem(context, Blocks.GRAVEL);
			}
			if (random.nextInt(2) == 0) {
				giveItem(context, ModItems.PEBBLE);
			}
			if (random.nextInt(8) == 0) {
				giveItem(context, Items.FLINT);
			}
			return true;
		} else if (block.equals(Blocks.COBBLED_DEEPSLATE.getDefaultState())) {
			world.breakBlock(pos, false);
			if (random.nextInt(10) == 0) {
				giveItem(context, Blocks.COARSE_DIRT);
			} else {
				giveItem(context, Blocks.GRAVEL);
			}
			if (random.nextInt(2) == 0) {
				giveItem(context, ModItems.DEEPSLATE_PEBBLE);
			}
			if (random.nextInt(6) == 0) {
				giveItem(context, ModItems.ASH_PILE);
			}
			return true;
		} else if (block.equals(Blocks.GRAVEL.getDefaultState())) {
			world.breakBlock(pos, false);
			giveItem(context, Blocks.SAND);
			if (random.nextInt(5) == 0) {
				giveItem(context, Items.FLINT);
			}
			if (random.nextInt(6) == 0) {
				giveItem(context, ModItems.GRAVEL_DUST);
			}
			if (random.nextInt(12) == 0) {
				giveItem(context, ModItems.IRON_PEBBLE);
			}
			if (random.nextInt(20) == 0) {
				giveItem(context, ModItems.GOLD_PEBBLE);
			}
			return true;
		} else if (block.equals(Blocks.SAND.getDefaultState())) {
			world.breakBlock(pos, false);
			giveItem(context, ModBlocks.DUST);
			if (random.nextInt(8) == 0) {
				giveItem(context, ModItems.IRON_DUST);
			}
			if (random.nextInt(12) == 0) {
				giveItem(context, ModItems.GOLD_DUST);
			}
			if (random.nextInt(24) == 0) {
				giveItem(context, Items.SUGAR_CANE);
			}
			if (random.nextInt(24) == 0) {
				giveItem(context, Items.CACTUS);
			}
			return true;
		} else if (block.equals(ModBlocks.DUST.getDefaultState())) {
			world.breakBlock(pos, false);
			if (random.nextInt(4) == 0) {
				giveItem(context, ModItems.BONE_DUST);
			}
			if (random.nextInt(5) == 0) {
				giveItem(context, ModItems.IRON_DUST);
			}
			return true;
		} else if (block.equals(Blocks.COARSE_DIRT.getDefaultState()) ||
				block.equals(Blocks.DIRT.getDefaultState())) {
			world.breakBlock(pos, false);
			if (block.equals(Blocks.COARSE_DIRT.getDefaultState())) {
				if (random.nextInt(3) == 0) {
					if (random.nextInt(2) == 0) {
						giveItem(context, ModItems.PEBBLE);
					}
					if (random.nextInt(2) == 0) {
						giveItem(context, ModItems.ANDESITE_PEBBLE);
					}
					if (random.nextInt(2) == 0) {
						giveItem(context, ModItems.DIORITE_PEBBLE);
					}
					if (random.nextInt(2) == 0) {
						giveItem(context, ModItems.GRANITE_PEBBLE);
					}
					if (random.nextInt(3) == 0) {
						giveItem(context, ModItems.DEEPSLATE_PEBBLE);
					}
				}
			}
			if (random.nextInt(12) == 0) {
				giveItem(context, Items.WHEAT_SEEDS);
			}
			if (random.nextInt(16) == 0) {
				giveItem(context, Items.BEETROOT_SEEDS);
			}
			if (random.nextInt(16) == 0) {
				giveItem(context, Items.MELON_SEEDS);
			}
			if (random.nextInt(16) == 0) {
				giveItem(context, Items.PUMPKIN_SEEDS);
			}
			if (random.nextInt(16) == 0) {
				giveItem(context, Items.CARROT);
			}
			if (random.nextInt(16) == 0) {
				giveItem(context, Items.POTATO);
			}
			if (random.nextInt(16) == 0) {
				giveItem(context, Items.COCOA_BEANS);
			}
			if (random.nextInt(12) == 0) {
				giveItem(context, Items.OAK_SAPLING);
			}
			if (random.nextInt(12) == 0) {
				giveItem(context, Items.SPRUCE_SAPLING);
			}
			if (random.nextInt(12) == 0) {
				giveItem(context, Items.ACACIA_SAPLING);
			}
			if (random.nextInt(12) == 0) {
				giveItem(context, Items.BIRCH_SAPLING);
			}
			if (random.nextInt(12) == 0) {
				giveItem(context, Items.JUNGLE_SAPLING);
			}
			if (random.nextInt(11) == 0) {
				giveItem(context, Items.DARK_OAK_SAPLING);
			}
			return true;
		}
		return false;
	}

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        if (!context.getWorld().isClient) {
            if (context.getSide().equals(Direction.UP)) {
                if (smashBlock(context)) {
                	damageItem(context);
					return ActionResult.CONSUME;
				}
            }
        }
        return super.useOnBlock(context);
    }
}
